 <?php
        
 
 $con = mysqli_connect('localhost','root','','db_etudiant');
 
 if(!$con){
     
     die('Please check your connection'.mysqli_error());
 }
 
 
 

