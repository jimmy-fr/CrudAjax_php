<?php

require_once 'includes/functions.php';
require_once 'includes/connexion.php';

get_record();
