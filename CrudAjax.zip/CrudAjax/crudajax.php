
<html>
    <head>
        <meta charset="UTF-8">
        <title>Page d'accueil</title>
<link type="text/css" href="ressources/css/style.css" rel="stylesheet">
<link type="text/css" href="ressources/css/bootstrap.min.css" rel="stylesheet">
<script type="text/javascript" src="ressources/js/jquery.js"></script>        
<script type="text/javascript" src="ressources/js/bootstrap.min.js"></script>
<link type="text/css" href="ressources/DataTables/datatables.min.css" rel="stylesheet">
<script type="text/javascript" src="ressources/DataTables/datatables.min.js"></script>
<script type="text/javascript" src="ressources/js/table.js"></script>

<script type="text/javascript" src="ressources/js/myjs.js"></script>

    </head>
    <body>
        
    
        <!-- titre -->
        <div class="container container-fluid p-5" align="center" >
           <h1 class="text text-primary">Crud avec Ajax Php</h1>  
        </div>
        
        <!-- bouton declencheur de modal pour l'enregistrement -->
        <div class="row p-2">
            <div class="col ml-5 my-2">
                
               <!-- bouton permettant de declencher le modal pour l'enregistrement -->
               <button  type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#registrationModal" data-bs-whatever="@getbootstrap">New Registration</button>  
            </div>
            
        </div>
        
        <div class="container container-fluid col-sm-auto" align="center">
            <strong><p id="delete_message" class="text text-success"></p></strong> 
        </div>
        

                         
            <!-- le modal pour l'enregistrement -->
            <div class="modal fade" id="registrationModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
               <div class="modal-content">
                <div class="modal-header">
                   <h1 class="modal-title fs-5 text-primary" id="exampleModalLabel">New Registration</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                        <div class="modal-body">
                        <strong><p id="message" class="text text-success"></p></strong> 
                            <form class="row g-3">
                             <div class="col-md-6">
                                 
                                <label for="recipient-name" class="form-label">Username</label>
                                <input  type="text" class="form-control" id="txt_username" placeholder="username" required="">
                             </div>
                             <div class="col-md-6">
                                <label for="recipient-name" class="form-label">User Email</label>
                                <input type="email" class="form-control" id="txt_mail" placeholder="email" required="">
                             </div> 
                                
                         
                          </form>
                        </div>
                          <div class="modal-footer">
                              <button type="button" class="btn btn-outline-dark" data-bs-dismiss="modal" id="btn_close">Close</button>
                             <button type="button" class="btn btn-success" id="btn_register">Save</button>
                          </div>
                </div>
             </div>
            </div>
            
            <!-- le modal pour la modification -->
            <div class="modal fade" id="updateModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
               <div class="modal-content">
                <div class="modal-header">
                   <h1 class="modal-title fs-5 text-primary" id="exampleModalLabel">Update users</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                        <div class="modal-body">
                        <strong><p id="up_message" class="text text-success"></p></strong> 
                        <form class=" row g-3">
                              
                             <div class="col-md-6">
                                 <input type="hidden" class="form-control" id="up_user_id" placeholder="email" required="">
                                 
                                <label for="recipient-name" class="col-form-label">Username</label>
                                <input type="text" class="form-control" id="up_txt_username" placeholder="username" required="">
                             </div>
                             <div class="col-md-6">
                                <label for="recipient-name" class="col-form-label">User Email</label>
                                <input type="email" class="form-control" id="up_txt_mail" placeholder="email" required="">
                                
                             </div> 
                                   
                          </form>
                        </div>
                          <div class="modal-footer">
                              <button type="button" class="btn btn-outline-dark" data-bs-dismiss="modal" id="btn_close_update">Close</button>
                             <button type="button" class="btn btn-success" id="btn_update">Update Now</button>
                          </div>
                </div>
             </div>
            </div>
                      <!-- le modals pour la suppression --> 
              
              <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title text-primary" id="exampleModalLabel">Suppression</h5>
                             <button type="button" class="btn btn-close" data-bs-dismiss="modal" aria-label="Close" ></button> 
                              
                          </div>
                          <div class="modal-body">
                            Voulez vous vraiment supprimer cet utilisateur? 
                            
                          </div>
                          <div class="modal-footer">
                              <button type="button" class="btn btn-outline-dark" data-bs-dismiss="modal">Annuler</button>
                              <button type="button" class="btn btn-danger" id="delete_record_button">Delete</button>
                          </div>
                          
                      </div>
                      
                  </div>
                  
              </div>
                      
                      
           <!--pour afficher le tableau des enregistrements -->  
           <div id="display_table">
               
           </div>
    
    </body>
</html>
