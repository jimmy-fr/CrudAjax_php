<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.122.0">
    <title>Page d'accueil</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/navbars-offcanvas/">

    

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    
<script type="text/javascript" src="ressources/js/jquery.js"></script>  
<link href="./assets/dist/css/bootstrap.min.css" rel="stylesheet">
<link type="text/css" href="./ressources/DataTables/datatables.min.css" rel="stylesheet">
<script type="text/javascript" src="./ressources/DataTables/datatables.min.js"></script>
<script type="text/javascript" src="./ressources/js/table.js"></script>

<script type="text/javascript" src="./ressources/js/myjs.js"></script>

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .b-example-divider {
        width: 100%;
        height: 3rem;
        background-color: rgba(0, 0, 0, .1);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }

      .btn-bd-primary {
        --bd-violet-bg: #712cf9;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

        --bs-btn-font-weight: 600;
        --bs-btn-color: var(--bs-white);
        --bs-btn-bg: var(--bd-violet-bg);
        --bs-btn-border-color: var(--bd-violet-bg);
        --bs-btn-hover-color: var(--bs-white);
        --bs-btn-hover-bg: #6528e0;
        --bs-btn-hover-border-color: #6528e0;
        --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
        --bs-btn-active-color: var(--bs-btn-hover-color);
        --bs-btn-active-bg: #5a23c8;
        --bs-btn-active-border-color: #5a23c8;
      }

      .bd-mode-toggle {
        z-index: 1500;
      }

      .bd-mode-toggle .dropdown-menu .active .bi {
        display: block !important;
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="./ressources/css/navbars-offcanvas.css" rel="stylesheet">
  </head>
  <body>
    
   
<main>
    <!-- le navbar -->
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-primary" aria-label="Offcanvas navbar large">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Application de gestion d'ecole</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar2" aria-controls="offcanvasNavbar2" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="offcanvas offcanvas-end text-bg-primary" tabindex="-1" id="offcanvasNavbar2" aria-labelledby="offcanvasNavbar2Label">
        <div class="offcanvas-header">
          <h5 class="offcanvas-title" id="offcanvasNavbar2Label">Menu</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#sectionHome">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#sectionUsers">Users</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Dropdown
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Action</a></li>
                <li><a class="dropdown-item" href="#">Another action</a></li>
                
                <li><a class="dropdown-item" href="#">Something else here</a></li>
              </ul>
            </li>
          </ul>
          <form class="d-flex mt-3 mt-lg-0" role="search">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-success" type="submit">Search</button>
          </form>
        </div>
      </div>
    </div>
  </nav>
    
    
    <!-- le container -->
  <div class="container container-fluid">
   
      <!-- section home -->
      <section id="sectionHome">
            <div class="mt-3">
                <div class="col-sm-auto py-md-5 mx-auto">
                  <h1 class="display-5 fw-normal">Home</h1>
                  <div class="right p-3">
                     <img src="./ressources/images/batiment.jpg"  class="img-fluid">
                  </div>
                
                </div>
             </div>
      </section>      
      
      
       <!-- section users -->
      <section id="sectionUsers">
            <div class="">
                <div class="col-sm-auto py-5 mx-auto">
                  <h1 class="display-5 fw-normal">Users</h1>
                  
                  
                  
                   <!-- bouton declencheur de modal pour l'enregistrement -->
        <div class="row p-2">
            <div class="col ml-5 my-2">
                
               <!-- bouton permettant de declencher le modal pour l'enregistrement -->
               <button  type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#registrationModal" data-bs-whatever="@getbootstrap">New Registration</button>  
            </div>
            
        </div>
        
        <div class="container container-fluid col-sm-auto" align="center">
            <strong><p id="delete_message" class="text text-success"></p></strong> 
        </div>
        

                         
            <!-- le modal pour l'enregistrement -->
            <div class="modal fade" id="registrationModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
               <div class="modal-content">
                <div class="modal-header">
                   <h1 class="modal-title fs-5 text-primary" id="exampleModalLabel">New Registration</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                        <div class="modal-body">
                        <strong><p id="message" class="text text-success"></p></strong> 
                            <form class="row g-3">
                             <div class="col-md-6">
                                 
                                <label for="recipient-name" class="form-label">Username</label>
                                <input  type="text" class="form-control" id="txt_username" placeholder="username" required="">
                             </div>
                             <div class="col-md-6">
                                <label for="recipient-name" class="form-label">User Email</label>
                                <input type="email" class="form-control" id="txt_mail" placeholder="email" required="">
                             </div> 
                                
                         
                          </form>
                        </div>
                          <div class="modal-footer">
                              <button type="button" class="btn btn-outline-dark" data-bs-dismiss="modal" id="btn_close">Close</button>
                             <button type="button" class="btn btn-success" id="btn_register">Save</button>
                          </div>
                </div>
             </div>
            </div>
            
            <!-- le modal pour la modification -->
            <div class="modal fade" id="updateModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
               <div class="modal-content">
                <div class="modal-header">
                   <h1 class="modal-title fs-5 text-primary" id="exampleModalLabel">Update users</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                        <div class="modal-body">
                        <strong><p id="up_message" class="text text-success"></p></strong> 
                        <form class=" row g-3">
                              
                             <div class="col-md-6">
                                 <input type="hidden" class="form-control" id="up_user_id" placeholder="email" required="">
                                 
                                <label for="recipient-name" class="col-form-label">Username</label>
                                <input type="text" class="form-control" id="up_txt_username" placeholder="username" required="">
                             </div>
                             <div class="col-md-6">
                                <label for="recipient-name" class="col-form-label">User Email</label>
                                <input type="email" class="form-control" id="up_txt_mail" placeholder="email" required="">
                                
                             </div> 
                                   
                          </form>
                        </div>
                          <div class="modal-footer">
                              <button type="button" class="btn btn-outline-dark" data-bs-dismiss="modal" id="btn_close_update">Close</button>
                             <button type="button" class="btn btn-success" id="btn_update">Update Now</button>
                          </div>
                </div>
             </div>
            </div>
                      <!-- le modals pour la suppression --> 
              
              <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title text-primary" id="exampleModalLabel">Suppression</h5>
                             <button type="button" class="btn btn-close" data-bs-dismiss="modal" aria-label="Close" ></button> 
                              
                          </div>
                          <div class="modal-body">
                            Voulez vous vraiment supprimer cet utilisateur? 
                            
                          </div>
                          <div class="modal-footer">
                              <button type="button" class="btn btn-outline-dark" data-bs-dismiss="modal">Annuler</button>
                              <button type="button" class="btn btn-danger" id="delete_record_button">Delete</button>
                          </div>
                          
                      </div>
                      
                  </div>
                  
              </div>
                      
                      
           <!--pour afficher le tableau des enregistrements -->  
           <div id="display_table">
               
           </div>
     
                  
                </div>
             </div>
      </section>  
      
      
      
  </div>
</main>
<script src="./assets/dist/js/bootstrap.bundle.min.js"></script>

    </body>
</html>


