<?php

require_once 'includes/functions.php';
require_once 'includes/connexion.php';
display_record();

