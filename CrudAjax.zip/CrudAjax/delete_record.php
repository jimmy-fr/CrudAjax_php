<?php


require_once 'includes/functions.php';
require_once 'includes/connexion.php';

delete_record();

