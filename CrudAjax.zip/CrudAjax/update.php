<?php

require_once 'includes/functions.php';
require_once 'includes/connexion.php';
update_record();

