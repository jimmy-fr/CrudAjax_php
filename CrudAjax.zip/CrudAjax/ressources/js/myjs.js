$(document).ready(function () {
    
    insert_record();
    view_record();
    get_record();
    update_record();
    delete_record();
   
   
   
    
})

//inserer des données dans la base de données
function insert_record(){
    
   $(document).on('click','#btn_register',function(){
       
    var user = $('#txt_username').val();//pour recuoerer la valeur dans le champ username
    var mail = $('#txt_mail').val();
    //console.log(user,mail);
    
    //gerer les erreurs
    if(user=="" || mail==""){
        $('#message').html('Remplir tous les champs svp');
    }else{
        
        
        $.ajax({
    url: 'insert.php',
    method: 'POST',
    data: { UName: user, UEmail: mail },
    success: function(data) {
        $('#message').html(data);
        $('#registrationModal').modal('show');
        $('form').trigger('reset');//pour vider les champs apres l'enregistrement
        view_record();//pour afficher le données inserées apres enregistrement
    },
    error: function(xhr, status, error) {
        console.error("Erreur AJAX:", error);
    }
});

        
    }

   });
   
   $(document).on('click','#btn_close',function(){
       
     $('form').trigger('reset');//pour vider les champs apres l'enregistrement
     $('#message').html('');
       
       
   })
    
}

//afficher les données

function view_record(){
    
    
    $.ajax({
        
        url: 'view.php',
        method: 'post',
        success: function (data) {
            
            data = $.parseJSON(data);
            if(data.status=='success'){
                
               $('#display_table').html(data.html);
                
            }
        }
        
        
    })
   
}


//recuperer un enregistrement

function get_record(){
    
    
    $(document).on('click','#btn_edit',function()
    {
        
        var ID = $(this).attr('data-id');
        //console.log(ID); 
    $.ajax({
    url: 'get_data.php',
    method: 'post',
    data: { UserID: ID },
    dataType: 'json',
    success: function(data) {
        if (data && data.length > 0) {
            // Mettre à jour les valeurs des champs dans le modal pour la modification
            $('#up_user_id').val(data[0].id);
            $('#up_txt_username').val(data[0].username);
            $('#up_txt_mail').val(data[0].mail);

            // Afficher le modal Bootstrap pour la modification
            $('#updateModal').modal('show');
        } else {
            // Gérer le cas où aucune donnée n'a été récupérée
            console.error('Aucune donnée d\'utilisateur récupérée');
        }
    },
    error: function(xhr, status, error) {
        console.error('Erreur AJAX lors de la récupération des données d\'utilisateur:', error);
    }
});

          
      })
      
      
    }
    
//fonction pour modifier

function update_record()
{
    
    
    
    
    $(document).on('click','#btn_update',function (){
        
        var UpdateId = $('#up_user_id').val();
        var UpdateUser = $('#up_txt_username').val();
        var UpdateMail = $('#up_txt_mail').val();
        if(UpdateUser=="" || UpdateMail==""){
            
           $('#up_message').html('Remplir les champs svp'); 
           $('#updateModal').modal('show'); 
        }else{
            
            $.ajax({
                
                url: 'update.php',
                method: 'post',
                data: {U_ID:UpdateId,U_User:UpdateUser,U_Mail:UpdateMail},
                success: function(data){
                    
                  //$('#up_message').html(data); 
                  $('#updateModal').modal('show');   
                  view_record();
                  $('#updateModal').modal('hide');
                  
                    
                }
                
                
                
            })
        }
        
    })
    
    $(document).on('click','#btn_close_update',function(){
       
     
     $('#up_message').html('');
       
       
   })
    
}

//fonction pour supprimer

function delete_record() {
    $(document).on('click', '#btn_delete', function() {
        
       
        // Envoyer une requête AJAX pour supprimer l'enregistrement
        var recordID = $(this).attr('data-id1'); // Obtenir l'ID de l'enregistrement à supprimer
         
        $('#deleteModal').modal('show');//pour afficher le modal de suppression
        
        $(document).on('click','#delete_record_button',function ()
        {
            
            $.ajax({
            url: 'delete_record.php',
            method: 'POST',
            data: { recordID: recordID },
            success: function(data) {
               
               view_record();
               //$('#delete_message').html(data).hide(8000);
               $('#deleteModal').modal('hide');//pour afficher le modal de suppression
               $('form').trigger('reset');//pour vider les champs apres l'enregistrement
               
               
            },
            error: function(xhr, status, error) {
                console.error('Erreur lors de la suppression de l\'enregistrement:', error);
            }
        });
            
            
        })
        
        
       
    });
}


    