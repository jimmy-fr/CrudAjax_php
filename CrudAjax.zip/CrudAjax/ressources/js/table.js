

//pour lancer la fonctionnalité de datatables

$(document).ready(function (){
   
    $('#users_table_registration').DataTable();
    
});


